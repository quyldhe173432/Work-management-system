﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace PRN212.Models;

public partial class Prn212Context : DbContext
{
    public Prn212Context()
    {
    }

    public Prn212Context(DbContextOptions<Prn212Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Action> Actions { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Status> Statuses { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("server =QUYDEPVAILINHHO; database = Prn212;uid=sa;pwd=123; TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Action>(entity =>
        {
            entity.HasKey(e => e.ActionId).HasName("PK__Actions__FFE3F4B987320BA8");

            entity.Property(e => e.ActionId).HasColumnName("ActionID");
            entity.Property(e => e.DateAction).HasColumnName("dateAction");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.TimeAction).HasColumnName("timeAction");

            entity.HasOne(d => d.Customer).WithMany(p => p.Actions)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("FK__Actions__Custome__286302EC");

            entity.HasOne(d => d.Status).WithMany(p => p.Actions)
                .HasForeignKey(d => d.StatusId)
                .HasConstraintName("FK__Actions__StatusI__29572725");
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.CustomerId).HasName("PK__Customer__A4AE64D879C5609B");

            entity.Property(e => e.Birthdate).HasColumnType("smalldatetime");
            entity.Property(e => e.CustomerName).HasMaxLength(50);
            entity.Property(e => e.Password)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Status>(entity =>
        {
            entity.HasKey(e => e.StatusId).HasName("PK__Status__C8EE2043F82F5FAA");

            entity.ToTable("Status");

            entity.Property(e => e.StatusId)
                .ValueGeneratedNever()
                .HasColumnName("StatusID");
            entity.Property(e => e.StatusName).HasMaxLength(50);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
