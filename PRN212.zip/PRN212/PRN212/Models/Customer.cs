﻿using System;
using System.Collections.Generic;

namespace PRN212.Models;

public partial class Customer
{
    public int CustomerId { get; set; }

    public string CustomerName { get; set; } = null!;

    public string Password { get; set; } = null!;

    public DateTime Birthdate { get; set; }

    public bool Gender { get; set; }

    public string? Address { get; set; }

    public virtual ICollection<Action> Actions { get; set; } = new List<Action>();
}
