﻿using System;
using System.Collections.Generic;

namespace PRN212.Models;

public partial class Action
{
    public int ActionId { get; set; }

    public int? CustomerId { get; set; }

    public string? ActionName { get; set; }

    public string? ActionDescription { get; set; }

    public string? DateAction { get; set; }

    public string? TimeAction { get; set; }

    public int? StatusId { get; set; }

    public virtual Customer? Customer { get; set; }

    public virtual Status? Status { get; set; }
}
