﻿using System;
using System.Collections.Generic;

namespace PRN212.Models;

public partial class Status
{
    public int StatusId { get; set; }

    public string? StatusName { get; set; }

    public virtual ICollection<Action> Actions { get; set; } = new List<Action>();
}
